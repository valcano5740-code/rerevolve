# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.9] - 2026-02-02

### Removed
- 🗑️ 작동하지 않는 OAuth 인증 버튼 제거 (Google OOB 방식 deprecated)

---

## [0.3.8] - 2026-02-02 ⭐ 주요 성공 사례

### Added
- 🎉 **Protobuf 기반 토큰 추출** (Antigravity Cockpit 방식)
  - `sql.js`로 state.vscdb SQLite 읽기
  - `jetskiStateSync.agentManagerInitState`에서 Protobuf 디코딩
  - **Refresh Token 추출 성공!**
- 정규식 방식 폴백 유지

### Technical
- `extractTokensWithProtobuf()` 메서드 추가
- Protobuf varint/length-delimited 필드 파싱
- OAuth 필드 (field 6) 에서 accessToken (field 1), refreshToken (field 3) 추출

### 참고
- Antigravity Cockpit의 `local_auth_importer.ts` 분석 기반
- 단순 정규식으로 추출 불가했던 refresh_token 획득 가능해짐

---

## [0.1.2] - 2026-01-30

### Fixed
- 🐛 이메일 추출 로직 버그 수정: `rerevolve.token.` 접두사가 이메일로 잘못 인식되는 문제 해결
- 정규식 패턴 이스케이프 수정

### Improved
- 충전/갱신 시간 UI 개선: 세로 배치로 줄바꿈 방지
- 예상 충전 시간 표시: 갱신 시점 + 남은 시간을 계산하여 날짜/시간(분 단위) 표시
- 갱신 시간에 날짜 추가 (M/D 오전/오후 H:MM 형식)

---

## [0.1.1] - 2026-01-30

### Fixed
- 🐛 토큰 캡처 시 현재 Antigravity 로그인 계정과 대상 계정 불일치 감지 기능 추가
  - 이제 다른 계정으로 로그인되어 있으면 경고 팝업이 표시됩니다
- 토큰 캡처 완료 시 실제 로그인 계정 정보 표시

### Added
- `getCurrentLoggedInEmail()` 메서드: state.vscdb에서 현재 로그인 이메일 추출

---

## [0.1.0] - 2026-01-30

### Added
- 초기 버전 릴리즈
- 다중 계정 쿼터 관리 기능
  - 계정 추가/삭제/수정
  - 유료/무료 계정 자동 판별
  - 무료 비활성화 계정 새로고침 잠금
- 토큰 관리 기능
  - state.vscdb에서 ya29 토큰 자동 추출
  - VSCode SecretStorage를 통한 안전한 토큰 저장
  - Refresh Token 기반 자동 갱신 (지원 시)
- 쿼터 조회 기능
  - CloudCode API를 통한 실시간 쿼터 조회
  - Claude/GPT, Gemini Pro, Gemini Flash 그룹별 집계
  - 리셋 시간 표시
- UI 기능
  - Webview 기반 사이드바 UI
  - 계정별 쿼터 카드
  - 전체/개별 새로고침 버튼
  - 🔑 토큰 캡처 버튼
- Antigravity 재시작 기능 (⚡ 번개 아이콘)
- 좌측 Activity Bar 아이콘

### Technical
- CloudCode API 엔드포인트: `daily-cloudcode-pa.sandbox.googleapis.com`
- 유/무료 판별: `loadCodeAssist` API의 `paidTier` 필드
- 토큰 추출: `state.vscdb` 파일에서 ya29 패턴 검색
