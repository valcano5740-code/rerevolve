/**
 * Auto-Accept Service - 코드 수정 및 터미널 명령 자동 승인
 * v2.0: Retry/Recovery 기능 추가
 */

import * as vscode from 'vscode';

// 위험 명령어 패턴
const DANGEROUS_PATTERNS = [
    /rm\s+-rf\s+[\/~\*]/i,           // rm -rf /, rm -rf ~, rm -rf *
    /rm\s+-fr\s+[\/~\*]/i,           // rm -fr 변형
    /del\s+\/[sfq]/i,                // del /f, del /s, del /q
    /format\s+[a-z]:/i,              // format C:
    /mkfs/i,                          // mkfs
    /dd\s+if=/i,                      // dd if=
    /:\s*\(\)\s*\{\s*:\s*\|\s*:/,     // fork bomb :(){ :|:& };:
    />\s*\/dev\/sda/i,                // > /dev/sda
];

export class AutoAcceptService implements vscode.Disposable {
    private interval: NodeJS.Timeout | null = null;
    private _enabled = false;
    private readonly intervalMs = 800;
    
    // 개별 옵션
    private acceptCodeEdits = true;
    private acceptTerminal = true;
    private blockDangerous = true;
    private autoRetry = true;        // 에러 시 자동 재시도
    private autoRecover = true;      // 멈춤 감지 및 복구
    
    // 상태 변경 이벤트
    private readonly _onStatusChange = new vscode.EventEmitter<boolean>();
    public readonly onStatusChange = this._onStatusChange.event;
    
    // 통계
    private stats = {
        codeAccepted: 0,
        terminalAccepted: 0,
        blockedCommands: 0,
        retryAttempts: 0,
        recoveryAttempts: 0
    };

    // 멈춤 감지용 타이머
    private lastActivityTime = Date.now();
    private stuckCheckInterval: NodeJS.Timeout | null = null;
    private readonly stuckThresholdMs = 30000; // 30초간 활동 없으면 멈춤으로 판단

    get isEnabled(): boolean {
        return this._enabled;
    }

    start(): void {
        if (this._enabled) return;
        
        this._enabled = true;
        this._onStatusChange.fire(true);
        this.lastActivityTime = Date.now();
        
        // 메인 폴링 인터벌
        this.interval = setInterval(async () => {
            await this.poll();
        }, this.intervalMs);

        // 멈춤 감지 인터벌 (10초마다 체크)
        if (this.autoRecover) {
            this.stuckCheckInterval = setInterval(async () => {
                await this.checkStuckAndRecover();
            }, 10000);
        }
        
        console.log('ReRevolve: Auto-Accept 활성화 🚀 (Retry/Recovery 포함)');
        vscode.window.showInformationMessage('🚀 Auto-Accept 활성화! 코드 수정, 터미널 명령, 재시도가 자동 처리됩니다.');
    }

    stop(): void {
        if (!this._enabled) return;
        
        this._enabled = false;
        this._onStatusChange.fire(false);
        
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }

        if (this.stuckCheckInterval) {
            clearInterval(this.stuckCheckInterval);
            this.stuckCheckInterval = null;
        }
        
        console.log('ReRevolve: Auto-Accept 비활성화');
        vscode.window.showInformationMessage('⏹️ Auto-Accept 비활성화');
    }

    toggle(): boolean {
        if (this._enabled) {
            this.stop();
        } else {
            this.start();
        }
        return this._enabled;
    }

    private async poll(): Promise<void> {
        if (!this._enabled) return;

        let anySuccess = false;

        // 1. 코드 수정 Accept (개별 스텝)
        if (this.acceptCodeEdits) {
            try {
                await vscode.commands.executeCommand('antigravity.agent.acceptAgentStep');
                anySuccess = true;
            } catch {
                // 무시 - pending step이 없으면 실패하는게 정상
            }
        }

        // 2. 터미널 명령 Accept
        if (this.acceptTerminal) {
            try {
                await vscode.commands.executeCommand('antigravity.terminal.accept');
                anySuccess = true;
            } catch {
                // 무시
            }

            // 터미널 명령 실행 (Run Command)
            try {
                await vscode.commands.executeCommand('antigravity.terminalCommand.accept');
                anySuccess = true;
            } catch {
                // 무시
            }
        }

        // 3. 일반 Accept 시도
        try {
            await vscode.commands.executeCommand('antigravity.command.accept');
            anySuccess = true;
        } catch {
            // 무시
        }

        // 4. Cascade 제안 Accept
        try {
            await vscode.commands.executeCommand('antigravity.interactiveCascade.acceptSuggestion');
            anySuccess = true;
        } catch {
            // 무시
        }

        // 5. 자동 재시도 (Retry prompts)
        if (this.autoRetry) {
            await this.handleRetryPrompts();
        }

        // 활동 감지 업데이트
        if (anySuccess) {
            this.lastActivityTime = Date.now();
        }
    }

    /**
     * 에러 발생 시 자동 재시도 처리
     * "다시 시도하시겠습니까?" 같은 프롬프트 자동 확인
     */
    private async handleRetryPrompts(): Promise<void> {
        const retryCommands = [
            'antigravity.agent.retry',
            'antigravity.retry',
            'antigravity.agent.continueConversation',
            'antigravity.continueTask',
        ];

        for (const cmd of retryCommands) {
            try {
                await vscode.commands.executeCommand(cmd);
                this.stats.retryAttempts++;
                console.log(`ReRevolve: Retry 명령 실행 - ${cmd}`);
            } catch {
                // 무시 - 명령어가 없거나 실행 불가
            }
        }
    }

    /**
     * Agent 멈춤 감지 및 자동 복구
     */
    private async checkStuckAndRecover(): Promise<void> {
        if (!this._enabled || !this.autoRecover) return;

        const now = Date.now();
        const elapsed = now - this.lastActivityTime;

        if (elapsed > this.stuckThresholdMs) {
            console.log(`ReRevolve: Agent 멈춤 감지 (${Math.round(elapsed / 1000)}초)`);
            
            // 복구 시도
            const recoveryCommands = [
                'antigravity.agent.restartAgent',
                'antigravity.restartAgentService',
                'antigravity.agent.cancelCurrentTask',
            ];

            for (const cmd of recoveryCommands) {
                try {
                    await vscode.commands.executeCommand(cmd);
                    this.stats.recoveryAttempts++;
                    console.log(`ReRevolve: 복구 명령 실행 - ${cmd}`);
                    this.lastActivityTime = Date.now(); // 리셋
                    break;
                } catch {
                    // 다음 명령 시도
                }
            }

            // 마지막 수단: 활성 편집기 포커스로 재활성화 시도
            try {
                const editor = vscode.window.activeTextEditor;
                if (editor) {
                    await vscode.window.showTextDocument(editor.document);
                }
            } catch {
                // 무시
            }

            // 활동 시간 리셋 (다음 체크까지 대기)
            this.lastActivityTime = Date.now();
        }
    }

    /**
     * 위험 명령어 체크 (향후 터미널 명령 필터링용)
     */
    isDangerousCommand(command: string): boolean {
        if (!this.blockDangerous) return false;
        
        for (const pattern of DANGEROUS_PATTERNS) {
            if (pattern.test(command)) {
                this.stats.blockedCommands++;
                console.log(`ReRevolve: 위험 명령어 차단됨 - ${command}`);
                return true;
            }
        }
        return false;
    }

    getStats() {
        return { ...this.stats };
    }

    setOptions(options: { 
        acceptCodeEdits?: boolean; 
        acceptTerminal?: boolean; 
        blockDangerous?: boolean;
        autoRetry?: boolean;
        autoRecover?: boolean;
    }): void {
        if (options.acceptCodeEdits !== undefined) this.acceptCodeEdits = options.acceptCodeEdits;
        if (options.acceptTerminal !== undefined) this.acceptTerminal = options.acceptTerminal;
        if (options.blockDangerous !== undefined) this.blockDangerous = options.blockDangerous;
        if (options.autoRetry !== undefined) this.autoRetry = options.autoRetry;
        if (options.autoRecover !== undefined) this.autoRecover = options.autoRecover;
    }

    dispose(): void {
        this.stop();
        this._onStatusChange.dispose();
    }
}
