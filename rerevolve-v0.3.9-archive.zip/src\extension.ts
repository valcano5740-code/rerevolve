/**
 * ReRevolve - Antigravity 다중 계정 쿼터 관리 확장프로그램
 * 진입점  
 */

import * as vscode from 'vscode';
import { SidebarProvider } from './sidebar-provider';
import { AccountManager } from './account-manager';
import { TokenService } from './token-service';
import { QuotaService, QuotaResult } from './quota-service';
import { AutoAcceptService } from './auto-accept-service';

let sidebarProvider: SidebarProvider;
let autoAcceptService: AutoAcceptService;
let statusBarItem: vscode.StatusBarItem;
let quotaStatusBarItem: vscode.StatusBarItem;
let tokenService: TokenService;
let quotaService: QuotaService;
let accountManager: AccountManager;

/**
 * Status Bar 아이템 상태 업데이트 (Auto-Accept)
 */
function updateStatusBarItem(enabled: boolean): void {
    if (enabled) {
        statusBarItem.text = '$(rocket) Auto-Accept: ON';
        statusBarItem.tooltip = 'ReRevolve Auto-Accept 활성 상태\n클릭하여 비활성화 (Ctrl+Alt+Shift+A)';
        statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
    } else {
        statusBarItem.text = '$(debug-stop) Auto-Accept: OFF';
        statusBarItem.tooltip = 'ReRevolve Auto-Accept 비활성 상태\n클릭하여 활성화 (Ctrl+Alt+Shift+A)';
        statusBarItem.backgroundColor = undefined;
    }
}

/**
 * 쿼터 상태바 업데이트 (활성 계정 Claude 쿼터)
 */
function updateQuotaStatusBar(email: string | null, quota: QuotaResult | null): void {
    if (!email || !quota) {
        quotaStatusBarItem.text = '$(pulse) Claude: --';
        quotaStatusBarItem.tooltip = '활성 계정 없음\n클릭하여 쿼터 새로고침';
        quotaStatusBarItem.backgroundColor = undefined;
        return;
    }

    const percent = Math.round(quota.claudeRemaining);
    const shortEmail = email.split('@')[0];
    
    // 색상 결정 (20% 이하: 경고, 50% 이하: 주의)
    if (percent <= 20) {
        quotaStatusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
    } else if (percent <= 50) {
        quotaStatusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
    } else {
        quotaStatusBarItem.backgroundColor = undefined;
    }

    quotaStatusBarItem.text = `$(pulse) ${shortEmail}: ${percent}%`;
    quotaStatusBarItem.tooltip = `${email}\nClaude 쿼터: ${percent}%\n리셋: ${quota.claudeResetTime || '정보 없음'}\n클릭하여 새로고침`;
}

export function activate(context: vscode.ExtensionContext) {
    console.log('ReRevolve: 확장 활성화');

    // 서비스 초기화
    const accountManager = new AccountManager(context);
    const tokenService = new TokenService(context.secrets);
    const quotaService = new QuotaService();
    autoAcceptService = new AutoAcceptService();

    // Status Bar 아이템 생성 (우측 우선순위 높게 배치)
    statusBarItem = vscode.window.createStatusBarItem(
        vscode.StatusBarAlignment.Right,
        1000 // 높은 우선순위로 오른쪽에 배치
    );
    statusBarItem.command = 'rerevolve.toggleAutoAccept';
    updateStatusBarItem(false);
    statusBarItem.show();
    context.subscriptions.push(statusBarItem);

    // 쿼터 상태바 아이템 생성 (Auto-Accept 왼쪽에 배치)
    quotaStatusBarItem = vscode.window.createStatusBarItem(
        vscode.StatusBarAlignment.Right,
        999 // Auto-Accept 바로 왼쪽
    );
    quotaStatusBarItem.command = 'rerevolve.refreshQuota';
    updateQuotaStatusBar(null, null);
    quotaStatusBarItem.show();
    context.subscriptions.push(quotaStatusBarItem);

    // Auto-Accept 상태 변경 시 StatusBar 업데이트
    autoAcceptService.onStatusChange((enabled) => {
        updateStatusBarItem(enabled);
    });

    // 사이드바 등록
    sidebarProvider = new SidebarProvider(
        context.extensionUri,
        accountManager,
        tokenService,
        quotaService,
        autoAcceptService
    );

    context.subscriptions.push(
        vscode.window.registerWebviewViewProvider(
            'rerevolve.quotaPanel',
            sidebarProvider
        )
    );

    // 명령어 등록
    context.subscriptions.push(
        vscode.commands.registerCommand('rerevolve.refreshAll', async () => {
            await sidebarProvider.refreshAll();
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('rerevolve.addAccount', async () => {
            await sidebarProvider.showAddAccountDialog();
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('rerevolve.captureToken', async () => {
            const email = await vscode.window.showInputBox({
                prompt: '토큰을 캡처할 이메일 주소 입력',
                placeHolder: 'example@gmail.com'
            });
            if (email) {
                await tokenService.captureCurrentToken(email);
                sidebarProvider.refresh();
            }
        })
    );

    // Auto-Accept 토글 명령어 (Ctrl+Alt+Shift+A)
    context.subscriptions.push(
        vscode.commands.registerCommand('rerevolve.toggleAutoAccept', () => {
            autoAcceptService.toggle();
        })
    );

    // Antigravity 재시작 명령어 (번개 아이콘)
    context.subscriptions.push(
        vscode.commands.registerCommand('rerevolve.reloadAntigravity', async () => {
            await vscode.commands.executeCommand('workbench.action.reloadWindow');
        })
    );

    // 쿼터 새로고침 명령어 (상태바 클릭 시)
    context.subscriptions.push(
        vscode.commands.registerCommand('rerevolve.refreshQuota', async () => {
            await refreshActiveQuota();
        })
    );

    // 활성 계정 쿼터 갱신 함수
    async function refreshActiveQuota(): Promise<void> {
        try {
            const activeEmail = await tokenService.getCurrentLoggedInEmail();
            if (!activeEmail) {
                updateQuotaStatusBar(null, null);
                return;
            }

            const token = await tokenService.getToken(activeEmail);
            if (!token) {
                updateQuotaStatusBar(activeEmail, null);
                return;
            }

            const quota = await quotaService.fetchQuota(activeEmail, token);
            updateQuotaStatusBar(activeEmail, quota);
        } catch (err) {
            console.error('ReRevolve: 쿼터 갱신 실패', err);
            updateQuotaStatusBar(null, null);
        }
    }

    console.log('ReRevolve: 초기화 완료');

    // 확장프로그램 시작 시 즉시 활성 계정 감지
    setTimeout(async () => {
        console.log('ReRevolve: 시작 시 활성 계정 감지');
        await sidebarProvider.refreshActiveOnly(); // 빠른 활성 계정 감지
        await refreshActiveQuota(); // 쿼터 상태바도 갱신
    }, 500); // 500ms 후 활성 계정 먼저 감지

    // 전체 쿼터 갱신은 2초 후
    setTimeout(async () => {
        console.log('ReRevolve: 시작 시 전체 갱신 실행');
        await sidebarProvider.refreshAll();
        await refreshActiveQuota(); // 쿼터 상태바도 갱신
    }, 2000);

    // 쿼터 상태바 60초마다 자동 갱신
    setInterval(async () => {
        await refreshActiveQuota();
    }, 60000);
}

export function deactivate() {
    console.log('ReRevolve: 확장 비활성화');
}
